#include <stdio.h>

void main(){
    int a, b, c, d;
    a = 1;
    b = 2;
    c = a / b; 
    d = a / c; 
}