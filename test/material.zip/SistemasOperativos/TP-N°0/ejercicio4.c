#include <stdio.h>

main(){
    char a = 'M';
    /*
        Aquí, se está usando el especificador de formato %i
        en printf para imprimir el valor de a como un número
        entero.
    */
    printf("a = %i \n" , a);

    /*
        Aquí, se está utilizando el especificador
        de formato %c en printf para imprimir el
        valor de a como un carácter. 
    */
    printf ("La letra %c \n", a);

    char sensor;
	float temp; 
	printf('La temperatura de %c es %f',sensor, temp);

}