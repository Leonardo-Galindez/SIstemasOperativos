#include <stdio.h>
/* El primer programa! */
main()
{
printf("Hola, gente!\n");
}