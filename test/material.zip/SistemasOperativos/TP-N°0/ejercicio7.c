#include <stdio.h>
main(){
    /*integer a;
    short i,j,k;
    long float (h);----
    double long d3;
    unsigned float n;-----
    char 2j;-----
    int MY;
    float ancho, alto, long;---
    bool i;---*/
}