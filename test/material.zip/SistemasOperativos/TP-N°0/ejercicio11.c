#include <stdio.h>
void main(){

    printf("%d",(double)100000*100000);
    printf(":%zu bytes\n",sizeof(int));
    
}