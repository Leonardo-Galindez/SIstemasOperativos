My CS 2110 GBA game project that is a clone of Arkanoid.

Press A to move from the start screen to the game.

Press B to release the ball from the paddle and the left and right arrow keys to move around.

Press Select to return to the start screen.
