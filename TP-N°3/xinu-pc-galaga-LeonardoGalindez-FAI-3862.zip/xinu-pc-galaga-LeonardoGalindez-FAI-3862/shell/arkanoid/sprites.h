/*
 * Exported with nin10kit v1.3
 * Invocation command was nin10kit -mode=3 sprites sprites.png 
 * Time-stamp: Tuesday 11/08/2016, 14:04:50
 * 
 * Image Information
 * -----------------
 * sprites.png 481@287
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef SPRITES_H
#define SPRITES_H

extern const unsigned short sprites[138047];
#define SPRITES_SIZE 138047
#define SPRITES_WIDTH 481
#define SPRITES_HEIGHT 287

#endif

